package com.guillin.edilson.Bibliteca;

@Service
public class GutendexService {

    private final RestTemplate restTemplate = new RestTemplate();
    private final String API_URL = "https://gutendex.com/books";

    public List<BookDTO> buscarLibros(String termino) {
        String url = UriComponentsBuilder.fromHttpUrl(API_URL)
                .queryParam("search", termino)
                .toUriString();

        // Realizar la solicitud a la API y mapear la respuesta
        String jsonResponse = restTemplate.getForObject(url, String.class);
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode rootNode = objectMapper.readTree(jsonResponse);
        return objectMapper.convertValue(rootNode.get("results"), new TypeReference<List<BookDTO>>() {});
    }
}
