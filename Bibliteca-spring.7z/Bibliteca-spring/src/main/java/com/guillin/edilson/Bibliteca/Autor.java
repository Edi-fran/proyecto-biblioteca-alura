package com.guillin.edilson.Bibliteca;

import jakarta.persistence.*;

@Entity
public class Autor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100) // El nombre es obligatorio y tiene un límite de caracteres
    private String nombre;

    @Column(name = "anio_nacimiento") // Opcional
    private Integer anioNacimiento;

    @Column(name = "anio_fallecimiento") // Opcional
    private Integer anioFallecimiento;

    // Constructor por defecto (necesario para JPA)
    public Autor() {
    }

    // Constructor completo
    public Autor(String nombre, Integer anioNacimiento, Integer anioFallecimiento) {
        setNombre(nombre); // Validación en el setter
        setAnioNacimiento(anioNacimiento); // Validación en el setter
        setAnioFallecimiento(anioFallecimiento); // Validación en el setter
    }

    // Constructor para crear un autor solo con nombre
    public Autor(String nombre) {
        setNombre(nombre); // Validación en el setter
    }

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre del autor no puede estar vacío.");
        }
        if (nombre.length() > 100) {
            throw new IllegalArgumentException("El nombre del autor no puede superar los 100 caracteres.");
        }
        this.nombre = nombre;
    }

    public Integer getAnioNacimiento() {
        return anioNacimiento;
    }

    public void setAnioNacimiento(Integer anioNacimiento) {
        if (anioNacimiento != null && anioNacimiento < 0) {
            throw new IllegalArgumentException("El año de nacimiento no puede ser negativo.");
        }
        this.anioNacimiento = anioNacimiento;
    }

    public Integer getAnioFallecimiento() {
        return anioFallecimiento;
    }

    public void setAnioFallecimiento(Integer anioFallecimiento) {
        if (anioFallecimiento != null && anioNacimiento != null && anioFallecimiento < anioNacimiento) {
            throw new IllegalArgumentException("El año de fallecimiento no puede ser anterior al año de nacimiento.");
        }
        this.anioFallecimiento = anioFallecimiento;
    }

    @Override
    public String toString() {
        return "Autor{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", anioNacimiento=" + (anioNacimiento != null ? anioNacimiento : "N/A") +
                ", anioFallecimiento=" + (anioFallecimiento != null ? anioFallecimiento : "N/A") +
                '}';
    }
}

