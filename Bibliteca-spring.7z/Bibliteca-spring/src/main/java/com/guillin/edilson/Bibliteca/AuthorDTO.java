package com.guillin.edilson.Bibliteca;

public class AuthorDTO {
    private String name;

    // Constructor por defecto
    public AuthorDTO() {
    }

    // Constructor completo
    public AuthorDTO(String name) {
        this.name = name;
    }

    // Getters y Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "AuthorDTO{" +
                "name='" + name + '\'' +
                '}';
    }
}

