package com.guillin.edilson.Bibliteca;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PrestamoRepository extends JpaRepository<Prestamo, Long> {

    // Buscar préstamos por el objeto Usuario
    List<Prestamo> findByUsuario(Usuario usuario);

    // Buscar préstamos por nombre del usuario
    List<Prestamo> findByUsuarioNombre(String nombre);

    // Buscar préstamos por correo del usuario
    List<Prestamo> findByUsuarioCorreo(String correo);

    // Buscar préstamos por nombre y correo del usuario
    List<Prestamo> findByUsuarioNombreAndUsuarioCorreo(String nombre, String correo);
}

