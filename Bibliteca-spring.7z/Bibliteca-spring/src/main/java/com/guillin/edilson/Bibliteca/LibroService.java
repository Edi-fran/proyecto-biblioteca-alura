package com.guillin.edilson.Bibliteca;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class LibroService {

    @Autowired
    private LibroRepository libroRepository;

    public void guardarLibro(Libro libro) {
        libroRepository.save(libro);
    }

    public List<Libro> listarTodosLosLibros() {
        return libroRepository.findAll();
    }

    public Libro buscarLibroPorId(Long id) {
        return libroRepository.findById(id).orElse(null);
    }
}
