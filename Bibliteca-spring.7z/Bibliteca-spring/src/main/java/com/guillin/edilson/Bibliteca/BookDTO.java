package com.guillin.edilson.Bibliteca;

import java.util.List;

public class BookDTO {
    private String title;
    private List<AuthorDTO> authors;

    // Constructor por defecto
    public BookDTO() {
    }

    // Constructor completo
    public BookDTO(String title, List<AuthorDTO> authors) {
        this.title = title;
        this.authors = authors;
    }

    // Getters y Setters
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<AuthorDTO> getAuthors() {
        return authors;
    }

    public void setAuthors(List<AuthorDTO> authors) {
        this.authors = authors;
    }

    @Override
    public String toString() {
        return "BookDTO{" +
                "title='" + title + '\'' +
                ", authors=" + authors +
                '}';
    }
}


