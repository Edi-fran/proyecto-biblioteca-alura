package com.guillin.edilson.Bibliteca;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.client.RestTemplate;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

@SpringBootApplication
public class BibliotecaSpringApplication implements CommandLineRunner {

    @Autowired
    private LibroService libroService;

    @Autowired
    private PrestamoRepository prestamoRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private AutorRepository autorRepository; // Repositorio para manejar autores

    private final RestTemplate restTemplate = new RestTemplate();
    private final Scanner scanner = new Scanner(System.in);
    private final String API_URL = "https://gutendex.com/books";

    public static void main(String[] args) {
        SpringApplication.run(BibliotecaSpringApplication.class, args);
    }

    @Override
    public void run(String... args) {
        mostrarMenu();
    }

    private void mostrarMenu() {
        while (true) {
            System.out.println("\n===== Menú de Biblioteca =====");
            System.out.println("1. Agregar un libro");
            System.out.println("2. Listar libros");
            System.out.println("3. Registrar un préstamo");
            System.out.println("4. Listar préstamos");
            System.out.println("5. Buscar libros desde la API");
            System.out.println("6. Salir");
            System.out.print("Selecciona una opción: ");

            try {
                int opcion = scanner.nextInt();
                scanner.nextLine(); // Limpiar el buffer

                switch (opcion) {
                    case 1 -> agregarLibro();
                    case 2 -> listarLibros();
                    case 3 -> registrarPrestamo();
                    case 4 -> listarPrestamos();
                    case 5 -> buscarLibrosDesdeAPI();
                    case 6 -> {
                        System.out.println("Gracias por usar la Biblioteca. ¡Hasta pronto!");
                        return;
                    }
                    default -> System.out.println("Opción inválida. Intenta nuevamente.");
                }
            } catch (Exception e) {
                System.out.println("Error: Entrada inválida. Intenta de nuevo.");
                scanner.nextLine(); // Limpiar el buffer en caso de error
            }
        }
    }

    private void agregarLibro() {
        try {
            System.out.print("Ingresa el título del libro: ");
            String titulo = scanner.nextLine();

            System.out.print("Ingresa el nombre del autor: ");
            String nombreAutor = scanner.nextLine();

            System.out.print("Ingresa el género del libro: ");
            String genero = scanner.nextLine();

            System.out.print("Ingresa el año de publicación del libro: ");
            int anioPublicacion = scanner.nextInt();

            System.out.print("Ingresa la cantidad disponible del libro: ");
            int cantidadDisponible = scanner.nextInt();
            scanner.nextLine(); // Limpiar el buffer

            // Buscar o crear el autor
            Autor autor = autorRepository.findByNombre(nombreAutor)
                    .orElseGet(() -> {
                        Autor nuevoAutor = new Autor(nombreAutor);
                        return autorRepository.save(nuevoAutor);
                    });

            // Crear el libro con todos los datos capturados
            Libro libro = new Libro(titulo, genero, anioPublicacion, cantidadDisponible, autor);

            // Guardar el libro en la base de datos
            libroService.guardarLibro(libro);
            System.out.println("Libro agregado exitosamente.");
        } catch (Exception e) {
            System.out.println("Error al agregar el libro: " + e.getMessage());
            scanner.nextLine(); // Limpiar el buffer en caso de error
        }
    }

    private void listarLibros() {
        System.out.println("\n===== Lista de Libros =====");
        libroService.listarTodosLosLibros().forEach(System.out::println);
    }

    private void registrarPrestamo() {
        try {
            System.out.print("Ingresa el ID del libro que deseas prestar: ");
            Long libroId = scanner.nextLong();
            scanner.nextLine(); // Limpiar el buffer

            System.out.print("Ingresa el nombre del usuario: ");
            String nombreUsuario = scanner.nextLine();

            System.out.print("Ingresa el correo del usuario: ");
            String correoUsuario = scanner.nextLine();

            System.out.print("Ingresa la fecha de devolución (YYYY-MM-DD): ");
            LocalDate fechaDevolucion = LocalDate.parse(scanner.nextLine());

            Libro libro = libroService.buscarLibroPorId(libroId);
            if (libro == null) {
                System.out.println("Libro no encontrado. Intenta nuevamente.");
                return;
            }

            Usuario usuario = usuarioRepository.findByNombreAndCorreo(nombreUsuario, correoUsuario)
                    .orElseGet(() -> {
                        // Crear el usuario si no existe
                        Usuario nuevoUsuario = new Usuario(nombreUsuario, correoUsuario, "123456789", LocalDate.now());
                        return usuarioRepository.save(nuevoUsuario);
                    });

            System.out.print("Ingresa el estado del préstamo (e.g., 'activo' o 'finalizado'): ");
            String estado = scanner.nextLine();

            // Crear el préstamo
            Prestamo prestamo = new Prestamo(libro, usuario, LocalDate.now(), fechaDevolucion, estado);
            prestamoRepository.save(prestamo);

            System.out.println("Préstamo registrado exitosamente.");
        } catch (Exception e) {
            System.out.println("Error al registrar el préstamo: " + e.getMessage());
            scanner.nextLine(); // Limpiar el buffer en caso de error
        }
    }

    private void listarPrestamos() {
        System.out.println("\n===== Lista de Préstamos =====");
        prestamoRepository.findAll().forEach(System.out::println);
    }

    private void buscarLibrosDesdeAPI() {
        try {
            System.out.print("Ingresa un término para buscar libros: ");
            String termino = scanner.nextLine();

            String url = API_URL + "?search=" + termino;
            String jsonResponse = restTemplate.getForObject(url, String.class);

            ObjectMapper mapper = new ObjectMapper();
            JsonNode root = mapper.readTree(jsonResponse);
            JsonNode results = root.get("results");

            if (results.isArray() && results.size() > 0) {
                for (JsonNode bookNode : results) {
                    String titulo = bookNode.get("title").asText();
                    String nombreAutor = bookNode.get("authors").size() > 0
                            ? bookNode.get("authors").get(0).get("name").asText()
                            : "Desconocido";

                    Autor autor = autorRepository.findByNombre(nombreAutor)
                            .orElseGet(() -> autorRepository.save(new Autor(nombreAutor)));

                    Libro libro = new Libro(titulo, "Desconocido", 2023, 1, autor);
                    libroService.guardarLibro(libro);
                }
                System.out.println("Libros agregados al catálogo desde la API.");
            } else {
                System.out.println("No se encontraron libros con el término proporcionado.");
            }
        } catch (Exception e) {
            System.out.println("Error al buscar libros en la API: " + e.getMessage());
        }
    }
}


